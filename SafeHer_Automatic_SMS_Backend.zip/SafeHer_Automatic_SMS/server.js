import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import twilio from "twilio";

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", 1);

const PORT = Number(process.env.PORT || 3000);
const allowedOrigins = (process.env.ALLOWED_ORIGINS || "")
  .split(",").map(v => v.trim()).filter(Boolean);

app.use(cors({
  origin(origin, callback) {
    // Allows health checks and server-to-server calls without an Origin header.
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error("Origin not allowed by CORS"));
  },
  methods: ["GET", "POST"],
  allowedHeaders: ["Content-Type"]
}));
app.use(express.json({ limit: "20kb" }));

const alertLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 3,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Rate limit reached. Try again later." }
});

function normalizePhone(value) {
  return String(value || "").replace(/[^\d+]/g, "");
}

function validPhone(value) {
  return /^\+[1-9]\d{7,14}$/.test(value);
}

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "SafeHer SMS backend" });
});

app.post("/api/emergency-alert", alertLimiter, async (req, res) => {
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const authToken = process.env.TWILIO_AUTH_TOKEN;
  const from = process.env.TWILIO_PHONE_NUMBER;

  if (!accountSid || !authToken || !from) {
    return res.status(503).json({ error: "SMS provider is not configured on the server." });
  }

  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  const rawContacts = Array.isArray(req.body?.contacts) ? req.body.contacts : [];

  if (!message || message.length > 1500) {
    return res.status(400).json({ error: "Message is required and must be at most 1500 characters." });
  }
  if (rawContacts.length < 1 || rawContacts.length > 5) {
    return res.status(400).json({ error: "Provide between 1 and 5 contacts." });
  }

  const contacts = rawContacts.map(c => ({
    name: String(c?.name || "Emergency contact").slice(0, 80),
    phone: normalizePhone(c?.phone)
  }));

  if (contacts.some(c => !validPhone(c.phone))) {
    return res.status(400).json({ error: "All phone numbers must use international format, e.g. +919876543210." });
  }

  // Avoid sending duplicates if the same number was added more than once.
  const uniqueContacts = [...new Map(contacts.map(c => [c.phone, c])).values()];
  const client = twilio(accountSid, authToken);

  const results = await Promise.all(uniqueContacts.map(async contact => {
    try {
      const result = await client.messages.create({
        body: message,
        from,
        to: contact.phone
      });
      return { name: contact.name, phone: contact.phone, status: result.status, sid: result.sid };
    } catch (error) {
      // Do not return provider credentials or stack traces to the browser.
      console.error("SMS provider rejected a message:", {
        code: error.code,
        status: error.status,
        message: error.message
      });
      return { name: contact.name, phone: contact.phone, error: "Provider rejected the message" };
    }
  }));

  const sent = results.filter(r => r.sid).length;
  const failed = results.length - sent;
  return res.status(200).json({ ok: failed === 0, sent, failed, results });
});

app.use((error, _req, res, _next) => {
  if (error.message === "Origin not allowed by CORS") {
    return res.status(403).json({ error: "This website origin is not allowed." });
  }
  console.error("Backend request error:", error.message);
  return res.status(400).json({ error: "Invalid request." });
});

app.listen(PORT, () => {
  console.log(`SafeHer SMS backend listening on port ${PORT}`);
});
